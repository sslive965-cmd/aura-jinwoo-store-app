# AURA JINWOO STORE - Android App

This is a separate Android project for the live AURA JINWOO STORE website.

Website:
https://sslive965-cmd.github.io/aura-jinwoo-shop/

The app uses WebView and hands non-web links such as `upi://` to Android so an installed UPI app can open them.

Manual UTR/payment verification on the website is unchanged.
